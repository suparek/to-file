# -*- coding:utf-8 -*-
from snippets.models import Snippet
from snippets.serializers import SnippetSerializer,UserSerializer
from django.contrib.auth.models import User
from rest_framework import permissions
from snippets.permissions import IsOwnerOrReadOnly

from rest_framework.decorators import api_view, renderer_classes
from rest_framework.response import Response
from rest_framework.reverse import reverse

from rest_framework import renderers

from rest_framework import viewsets

from rest_framework.decorators import detail_route

# from rest_framework_swagger.renderers import OpenAPIRenderer, SwaggerUIRenderer

# @api_view()
# @renderer_classes([SwaggerUIRenderer, OpenAPIRenderer])
# def schema_view(request):
#     generator = schemas.SchemaGenerator(title='Core API')
#     return response.Response(generator.get_schema(request=request))

class SnippetViewSet(viewsets.ModelViewSet):
    """
    这个 `list`, `create`, `retrieve`,
    `update` and `destroy` actions.

    Additionally we also provide an extra `highlight` action.
    """
    queryset = Snippet.objects.all()
    serializer_class = SnippetSerializer
    permission_classes = (permissions.IsAuthenticatedOrReadOnly,
                          IsOwnerOrReadOnly,)

    @detail_route(renderer_classes=[renderers.StaticHTMLRenderer])
    def highlight(self, request, *args, **kwargs):
        """
        就是这样的吧
        """
        snippet = self.get_object()
        return Response(snippet.highlighted)

    def perform_create(self, serializer):
        serializer.save(owner=self.request.user)



class UserViewSet(viewsets.ReadOnlyModelViewSet):
    """
    This viewset automatically provides `list` and `detail` actions.
    """
    queryset = User.objects.all()
    serializer_class = UserSerializer


@api_view(['GET'])
def api_root(request, format=None):
    return Response({
        'users': reverse('user-list', request=request, format=format),
        'snippets': reverse('snippet-list', request=request, format=format)
    })

@api_view(['GET','POST'])
def vm_connect(request, *args):
    if request.method == 'GET':
        for k in request.query_params:
            dict[k] = request.query_params[k]
        return Response(dict)
    elif request.method == 'POST':
        for k in request.data:
            dict[k] = request.data[k]
        return Response(dict)
